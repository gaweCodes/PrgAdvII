﻿namespace SysInventory.LogMessages
{
    internal enum DatabaseRequestType
    {
        Query = 0,
        StoredProcedure = 1
    }
}
