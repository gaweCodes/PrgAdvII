﻿using System.Windows;

namespace SysInventory.LogMessages
{
    public partial class AddDialog : Window
    {
        public AddDialog() => InitializeComponent();
    }
}
