﻿using System.Windows.Controls;

namespace SysInventory.LogMessages
{
        public partial class LogMessages : UserControl
        {
            public LogMessages() => InitializeComponent();
        }
}
