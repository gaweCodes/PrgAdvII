﻿namespace DuplicateCheckerLib {
    public interface IEntity { }
}
